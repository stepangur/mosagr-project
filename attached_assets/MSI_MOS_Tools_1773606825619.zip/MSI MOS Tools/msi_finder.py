bl_info = {
    "name": "MSI MOS Finder",
    "blender": (2, 80, 0),
    "category": "UV",
}
import bpy
import bmesh
import math
from mathutils import Vector
from bpy.types import Operator, Panel
TEXTURE_RESOLUTION = 4096
UV_LAYER_NAME = "UVMap"
def select_faces_by_density(threshold, mode='LOW'):
    obj = bpy.context.active_object
    if not obj or obj.type != 'MESH':
        return f"❌ Объект не является Mesh"
    bpy.ops.object.mode_set(mode='EDIT')
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.get(UV_LAYER_NAME)
    if not uv_layer:
        return f"❌ UV слой '{UV_LAYER_NAME}' не найден."
    count = 0
    for face in bm.faces:
        face.select_set(False)
        area_3d = face.calc_area()
        if area_3d == 0:
            continue
        uv_coords = [loop[uv_layer].uv for loop in face.loops]
        area_uv = 0
        for i in range(len(uv_coords)):
            p1 = uv_coords[i]
            p2 = uv_coords[(i + 1) % len(uv_coords)]
            area_uv += (p1.x * p2.y - p2.x * p1.y)
        area_uv = abs(area_uv) * 0.5
        density = math.sqrt((area_uv * (TEXTURE_RESOLUTION ** 2)) / area_3d)
        if (mode == 'LOW' and density < threshold) or (mode == 'HIGH' and density > threshold):
            face.select_set(True)
            count += 1
    bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=False)
    if count > 0:
        return f"🔍 Найдено {count} фейсов ({'<' if mode == 'LOW' else '>'} {threshold}px/m)"
    else:
        return "✅ Все фейсы соответствуют заданной плотности."
class TEXELDENSITY_OT_CheckLow(Operator):
    """Ищет шеллы с текселем, который ниже допустимого значения"""
    bl_idname = "mesh.check_texel_density_low"
    bl_label = "Плотность < 512 px/m"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        msg = select_faces_by_density(512, mode='LOW')
        self.report({'INFO'}, msg)
        return {'FINISHED'}
class TEXELDENSITY_OT_CheckHigh(Operator):
    """Ищет шеллы с текселем, который выше допустимого значения"""
    bl_idname = "mesh.check_texel_density_high"
    bl_label = "Плотность > 1706 px/m"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        msg = select_faces_by_density(1706, mode='HIGH')
        self.report({'INFO'}, msg)
        return {'FINISHED'}
def angle_between_vectors(v1, v2):
    v1_n = v1.normalized()
    v2_n = v2.normalized()
    dot = max(min(v1_n.dot(v2_n), 1.0), -1.0)
    return math.degrees(math.acos(dot))
def select_faces_with_angle_distortion(threshold=20):
    obj = bpy.context.active_object
    if not obj or obj.type != 'MESH':
        return "❌ Объект не является Mesh"
    bpy.ops.object.mode_set(mode='EDIT')
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.get(UV_LAYER_NAME)
    if not uv_layer:
        return f"❌ UV слой '{UV_LAYER_NAME}' не найден."
    count_distorted = 0
    for face in bm.faces:
        face.select_set(False)
        if len(face.loops) not in {3, 4}:
            continue
        is_distorted = False
        for i, loop in enumerate(face.loops):
            loop_prev = face.loops[i - 1]
            loop_next = face.loops[(i + 1) % len(face.loops)]
            edge1_3d = loop_prev.vert.co - loop.vert.co
            edge2_3d = loop_next.vert.co - loop.vert.co
            angle_3d = angle_between_vectors(edge1_3d, edge2_3d)
            uv1 = loop_prev[uv_layer].uv
            uv2 = loop[uv_layer].uv
            uv3 = loop_next[uv_layer].uv
            edge1_uv = uv1 - uv2
            edge2_uv = uv3 - uv2
            angle_uv = angle_between_vectors(edge1_uv, edge2_uv)
            if abs(angle_3d - angle_uv) > threshold:
                is_distorted = True
                break
        if is_distorted:
            face.select_set(True)
            count_distorted += 1
    bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=False)
    if count_distorted > 0:
        return f"🔍 Найдено {count_distorted} искажённых фейсов (угловое искажение > {threshold}°)"
    else:
        return "✅ Явных искажений не найдено"
class TEXELDENSITY_OT_CheckAngleDistortion(Operator):
    """Ищет полигоны, которые имеют искажения по отношению к своей развертке в UV пространстве и наоборот"""
    bl_idname = "mesh.check_angle_distortion"
    bl_label = "Найти растяжения"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        msg = select_faces_with_angle_distortion(threshold=20)
        self.report({'INFO'}, msg)
        return {'FINISHED'}
class MESH_OT_MergeAndShowIntersect(Operator):
    """Объединяет коллизии в один мэш и запускает аналитику интерсекции (в версии 4.4.3 пока недоступен запуск аналитики в автоматическом режиме)"""
    bl_idname = "mesh.combine_and_show_intersect"
    bl_label = "Проверить коллизии"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        selected = [obj for obj in context.scene.objects if obj.type == 'MESH' and obj.name.startswith('UCX')]
        if not selected or len(selected) < 2:
            self.report({'ERROR'}, "Выделите минимум два объекта типа Mesh.")
            return {'CANCELLED'}
        names = [obj.name for obj in selected]
        context.view_layer.objects.active = selected[-1]
        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected:
            obj.select_set(True)
        bpy.ops.object.join()
        merged = bpy.context.active_object
        merged["original_object_names"] = names
        bpy.ops.object.mode_set(mode='EDIT')
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        try:
                            space.overlay.statvis.show_intersections = True
                        except:
                            pass
                        self.report({'INFO'}, "✅ Объединение и визуализация завершены.")
                        return {'FINISHED'}
        return {'CANCELLED'}
class MESH_OT_SeparateLooseParts(Operator):
    """Разделяет мэш, на котором делали аналитику интерсекции для поиска пересечений, сохраняет наименование коллизий"""
    bl_idname = "mesh.separate_loose_parts"
    bl_label = "Разделить коллизии"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        before = set(bpy.data.objects)
        try:
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as e:
            self.report({'ERROR'}, f"Ошибка при разделении: {e}")
            return {'CANCELLED'}
        after = set(bpy.data.objects)
        new_objs = list(after - before)
        name_source = context.selected_objects[0]
        if "original_object_names" in name_source:
            for i, obj in enumerate(new_objs):
                if i < len(name_source["original_object_names"]):
                    obj.name = name_source["original_object_names"][i]
        self.report({'INFO'}, f"🔄 Объект разделён. Восстановлено имён: {min(len(new_objs), len(name_source['original_object_names']))}")
        return {'FINISHED'}
class TEXELDENSITY_PT_MainPanel(Panel):
    bl_label = "MSI MOS Finder"
    bl_idname = "VIEW3D_PT_msi_mos_finder"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MSI Tools"  # 'MSI 25 Finder'
    def draw(self, context):
        layout = self.layout
        # Блок: Проверка текселя
        box = layout.box()
        box.label(text="Проверка текселя", icon="KEYTYPE_BREAKDOWN_VEC")
        box.operator("mesh.check_texel_density_low", icon="ZOOM_OUT")
        box.operator("mesh.check_texel_density_high", icon="ZOOM_IN")
        layout.separator()
        # Блок: Отображение коллизий
        box = layout.box()
        box.label(text="Отображение коллизий", icon="KEYTYPE_BREAKDOWN_VEC")
        box.operator("object.hide_ucx", icon="HIDE_ON")
        box.operator("object.show_ucx", icon="HIDE_OFF")
        layout.separator()
        # Блок: Поиск искажений
        box = layout.box()
        box.label(text="Поиск искажений", icon="KEYTYPE_BREAKDOWN_VEC")
        box.operator("msi25.fix_flipped_uvs", icon="MOD_MIRROR")
        box.operator("mesh.check_angle_distortion", icon="MOD_SMOOTH")
        box.operator("mesh.select_non_manifold_edges", icon="MOD_EDGESPLIT")
        layout.separator()
        # Блок: Поиск пересечений
        box = layout.box()
        box.label(text="Поиск пересечений", icon="KEYTYPE_BREAKDOWN_VEC")
        box.operator("mesh.combine_and_show_intersect", icon="MOD_BOOLEAN")
        box.operator("mesh.separate_loose_parts", icon="UV_ISLANDSEL")
        layout.separator()
        # Блок: Подготовка к экспорту
        box = layout.box()
        box.label(text="Подготовка к экспорту", icon="KEYTYPE_JITTER_VEC")
        box.operator("mesh.merge_visible_by_distance", icon="AUTOMERGE_ON")
        box.operator("object.remove_color_attrs", icon="BRUSH_DATA")
        box.operator("mesh.triangulate_visible", icon="MOD_TRIANGULATE")
        box.operator("mesh.select_loose_geometry", icon="VERTEXSEL")
class MESH_OT_SelectNonManifoldEdges(bpy.types.Operator):
    """Ищет участки, у которых один и более вертексов не связаны с остальной геометрией"""
    bl_idname = "mesh.select_non_manifold_edges"
    bl_label = "Найти несшитые участки"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = bpy.context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "Выделите объект типа MESH.")
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.context.tool_settings.mesh_select_mode[:] = (False, True, False)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_non_manifold()
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "✅ Non-manifold рёбра выделены.")
        return {'FINISHED'}
class MESH_OT_MergeVisibleByDistance(bpy.types.Operator):
    """Объединяет вертексы, захват на 0.002 м"""
    bl_idname = "mesh.merge_visible_by_distance"
    bl_label = "Смерджить вершины"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        for obj in context.visible_objects:
            obj.select_set(obj.type == 'MESH')
        active = context.selected_objects[0] if context.selected_objects else None
        context.view_layer.objects.active = active
        if not active:
            self.report({'WARNING'}, "Нет видимых объектов типа Mesh")
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles(threshold=0.002)
        return {'FINISHED'}
class OBJECT_OT_RemoveColorAttributes(bpy.types.Operator):
    """Удаляет все Color Attributes у всех объектов"""
    bl_idname = "object.remove_color_attrs"
    bl_label = "Удалить Color Attributes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        removed_count = 0
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                attrs = obj.data.color_attributes
                for attr in list(attrs):
                    attrs.remove(attr)
                    removed_count += 1
        self.report({'INFO'}, f"🧹 Удалено Color Attributes: {removed_count}")
        return {'FINISHED'}    
class MESH_OT_TriangulateVisible(bpy.types.Operator):
    """Триангулирует все видимые объекты"""
    bl_idname = "mesh.triangulate_visible"
    bl_label = "Триангулировать"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        for obj in context.visible_objects:
            obj.select_set(obj.type == 'MESH')
        active = context.selected_objects[0] if context.selected_objects else None
        context.view_layer.objects.active = active
        if not active:
            self.report({'WARNING'}, "Нет видимых объектов типа Mesh")
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.quads_convert_to_tris()
        return {'FINISHED'}
class MESH_OT_SelectLooseGeometry(bpy.types.Operator):
    """Выделяет изолированные вершины во всех видимых объектах"""
    bl_idname = "mesh.select_loose_geometry"
    bl_label = "Показать изолированные вершины"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        for obj in context.visible_objects:
            obj.select_set(obj.type == 'MESH')
        active = context.selected_objects[0] if context.selected_objects else None
        context.view_layer.objects.active = active
        if not active:
            self.report({'WARNING'}, "Нет видимых объектов типа Mesh")
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.select_loose()
        return {'FINISHED'}


class OBJECT_OT_HideUCX(bpy.types.Operator):
    """Скрывает все коллизии"""
    bl_idname = "object.hide_ucx"
    bl_label = "Скрыть коллизии"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for obj in bpy.data.objects:
            if "UCX" in obj.name:
                obj.select_set(True)
                obj.hide_set(True)
                count += 1
        self.report({'INFO'}, f"✅ Скрыто объектов: {count}")
        return {'FINISHED'}



class OBJECT_OT_ShowUCX(bpy.types.Operator):
    """Показывает все скрытые коллизии"""
    bl_idname = "object.show_ucx"
    bl_label = "Показать коллизии"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for obj in bpy.data.objects:
            if "UCX" in obj.name:
                obj.select_set(True)
                obj.hide_set(False)
                count += 1
        self.report({'INFO'}, f"👁️ Показано объектов: {count}")
        return {'FINISHED'}





classes = (
    TEXELDENSITY_OT_CheckLow,
    TEXELDENSITY_OT_CheckHigh,
    TEXELDENSITY_OT_CheckAngleDistortion,
    MESH_OT_MergeAndShowIntersect,
    MESH_OT_SeparateLooseParts,
    MESH_OT_SelectNonManifoldEdges,
    MESH_OT_MergeVisibleByDistance,
    MESH_OT_TriangulateVisible,
    MESH_OT_SelectLooseGeometry,
    OBJECT_OT_RemoveColorAttributes,
    OBJECT_OT_ShowUCX,
    OBJECT_OT_HideUCX,
    TEXELDENSITY_PT_MainPanel,
)
def fix_mirrored_uv_islands():
    import bmesh
    obj = bpy.context.active_object
    if not obj or obj.type != 'MESH':
        print("❌ Выберите объект типа MESH.")
        return
    if bpy.context.object.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)
    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        print("❌ Не найден активный UV-слой.")
        return
    bm.faces.ensure_lookup_table()
    mirrored_count = 0
    for face in bm.faces:
        if len(face.loops) < 3:
            continue
        uv1 = face.loops[0][uv_layer].uv
        uv2 = face.loops[1][uv_layer].uv
        uv3 = face.loops[2][uv_layer].uv
        v1 = uv2 - uv1
        v2 = uv3 - uv1
        cross = v1.x * v2.y - v1.y * v2.x
        if cross < 0:
            face.select = True
            mirrored_count += 1
        else:
            face.select = False
    bmesh.update_edit_mesh(obj.data)
    print(f"✅ Найдено зеркальных полигонов: {mirrored_count}. Чтобы отразить их вручную — S > X > -1 в UV Editor.")
class MSI25_OT_FixFlippedUVs(bpy.types.Operator):
    bl_idname = "msi25.fix_flipped_uvs"
    bl_label = "Найти отражённые острова"
    bl_description = "Выделяет UV-шеллы, которые развернуты зеркально относительно геометрии"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        fix_mirrored_uv_islands()
        return {'FINISHED'}
def register():
    bpy.utils.register_class(MSI25_OT_FixFlippedUVs)
    for cls in classes:
        bpy.utils.register_class(cls)
def unregister():
    bpy.utils.unregister_class(MSI25_OT_FixFlippedUVs)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
if __name__ == "__main__":
    register()

class OBJECT_OT_HideUCX(bpy.types.Operator):
    """Скрывает все коллизии"""
    bl_idname = "object.hide_ucx"
    bl_label = "Скрыть коллизии"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for obj in bpy.data.objects:
            if "UCX" in obj.name:
                obj.select_set(True)
                obj.hide_set(True)
                count += 1
        self.report({'INFO'}, f"✅ Скрыто объектов: {count}")
        return {'FINISHED'}
