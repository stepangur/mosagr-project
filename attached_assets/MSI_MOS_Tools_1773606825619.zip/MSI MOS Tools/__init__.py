bl_info = {
    "name": "MSI MOS Tools",
    "blender": (2, 80, 0),
    "category": "3D View"
}

import bpy
from . import msi_finder
from . import geojson_ex

def register():
    msi_finder.register()
    geojson_ex.register()

def unregister():
    geojson_ex.unregister()
    msi_finder.unregister()
