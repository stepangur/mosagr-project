bl_info = {
    "name": "GEOJSON Export Panel",
    "blender": (3, 0, 0),
    "category": "3D View",
}

import bpy
import json
import base64
import os
from collections import OrderedDict

class GlassItem(bpy.types.PropertyGroup):
    material_name: bpy.props.StringProperty(name="material name")
    R: bpy.props.StringProperty(name="R")
    G: bpy.props.StringProperty(name="G")
    B: bpy.props.StringProperty(name="B")
    transparency: bpy.props.StringProperty(name="transparency")
    refraction: bpy.props.StringProperty(name="refraction")
    roughness: bpy.props.StringProperty(name="roughness")
    metallicity: bpy.props.StringProperty(name="metallicity")

class GeoJSONProperties(bpy.types.PropertyGroup):
    address: bpy.props.StringProperty(name="address")
    okrug: bpy.props.StringProperty(name="okrug")
    rajon: bpy.props.StringProperty(name="rajon")
    name: bpy.props.StringProperty(name="name")
    developer: bpy.props.StringProperty(name="developer")
    designer: bpy.props.StringProperty(name="designer")
    cadNum: bpy.props.StringProperty(name="cadNum")
    FNO_code: bpy.props.StringProperty(name="FNO_code")
    FNO_name: bpy.props.StringProperty(name="FNO_name")
    ZU_area: bpy.props.StringProperty(name="ZU_area")
    h_relief: bpy.props.StringProperty(name="h_relief")
    h_otn: bpy.props.StringProperty(name="h_otn")
    h_abs: bpy.props.StringProperty(name="h_abs")
    s_obsh: bpy.props.StringProperty(name="s_obsh")
    s_naz: bpy.props.StringProperty(name="s_naz")
    s_podz: bpy.props.StringProperty(name="s_podz")
    spp_gns: bpy.props.StringProperty(name="spp_gns")
    act_AGR: bpy.props.StringProperty(name="act_AGR")
    image: bpy.props.StringProperty(name="Image", subtype='FILE_PATH')
    other: bpy.props.StringProperty(name="other")
    coord_x: bpy.props.StringProperty(name="X")
    coord_y: bpy.props.StringProperty(name="Y")

    glasses: bpy.props.CollectionProperty(type=GlassItem)
    active_glass_index: bpy.props.IntProperty()

class GEOJSON_OT_add_glass(bpy.types.Operator):
    bl_idname = "geojson.add_glass"
    bl_label = "Добавить стекло"

    def execute(self, context):
        context.scene.geojson_props.glasses.add()
        return {'FINISHED'}

class GEOJSON_OT_remove_glass(bpy.types.Operator):
    bl_idname = "geojson.remove_glass"
    bl_label = "Удалить стекло"

    index: bpy.props.IntProperty()

    def execute(self, context):
        props = context.scene.geojson_props
        if 0 <= self.index < len(props.glasses):
            props.glasses.remove(self.index)
        return {'FINISHED'}

class GEOJSON_OT_clear_image(bpy.types.Operator):
    bl_idname = "geojson.clear_image"
    bl_label = "Очистить изображение"

    def execute(self, context):
        props = context.scene.geojson_props
        props.image = ""
        return {'FINISHED'}

class GEOJSON_OT_export(bpy.types.Operator):
    bl_idname = "geojson.export"
    bl_label = "Export GEOJSON"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        props = context.scene.geojson_props

        try:
            coord_x = float(props.coord_x.replace(',', '.'))
            coord_y = float(props.coord_y.replace(',', '.'))
        except ValueError:
            coord_x, coord_y = 0.0, 0.0

        image_base64 = ""
        if props.image:
            path = bpy.path.abspath(props.image)
            ext = os.path.splitext(path)[-1].lower()
            if ext not in [".jpg", ".jpeg"]:
                self.report({'ERROR'}, "Можно загрузить только .jpg/.jpeg изображение")
                props.image = ""
            elif os.path.isfile(path):
                with open(path, "rb") as img_file:
                    image_base64 = base64.b64encode(img_file.read()).decode('utf-8')

        glasses_array = []
        for glass in props.glasses:
            material_name = glass.material_name.strip()
            if not material_name:
                continue
            entry = OrderedDict([
                (material_name, OrderedDict([
                    ("color_RGB", OrderedDict([
                        ("Red", glass.R),
                        ("Green", glass.G),
                        ("Blue", glass.B)
                    ])),
                    ("transparency", glass.transparency),
                    ("refraction", glass.refraction),
                    ("roughness", glass.roughness),
                    ("metallicity", glass.metallicity)
                ]))
            ])
            glasses_array.append(entry)

        properties = OrderedDict([
            ("address", props.address),
            ("okrug", props.okrug),
            ("rajon", props.rajon),
            ("name", props.name),
            ("developer", props.developer),
            ("designer", props.designer),
            ("cadNum", props.cadNum),
            ("FNO_code", props.FNO_code),
            ("FNO_name", props.FNO_name),
            ("ZU_area", props.ZU_area),
            ("h_relief", props.h_relief),
            ("h_otn", props.h_otn),
            ("h_abs", props.h_abs),
            ("s_obsh", props.s_obsh),
            ("s_naz", props.s_naz),
            ("s_podz", props.s_podz),
            ("spp_gns", props.spp_gns),
            ("act_AGR", props.act_AGR),
            ("imageBase64", image_base64),
            ("other", props.other)
        ])

        data = OrderedDict([
            ("type", "FeatureCollection"),
            ("features", [
                OrderedDict([
                    ("type", "ObjectFeature"),
                    ("properties", properties),
                    ("geometry", OrderedDict([
                        ("type", "Point"),
                        ("coordinates", [coord_x, coord_y])
                    ])),
                    ("Glasses", OrderedDict(glass for g in glasses_array for glass in g.items()))
                ])
            ])
        ])

        if not self.filepath.lower().endswith(".geojson"):
            self.filepath += ".geojson"

        with open(self.filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        self.report({'INFO'}, f"GEOJSON exported to {self.filepath}")
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class GEOJSON_PT_panel(bpy.types.Panel):
    bl_label = "GEOJSON Export"
    bl_idname = "GEOJSON_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MSI Tools"  # "GEOJSON"

    def draw(self, context):
        layout = self.layout
        props = context.scene.geojson_props

        col = layout.column()
        col.prop(props, "address")
        col.prop(props, "okrug")
        col.prop(props, "rajon")
        col.prop(props, "name")
        col.prop(props, "developer")
        col.prop(props, "designer")
        col.prop(props, "cadNum")
        col.prop(props, "FNO_code")
        col.prop(props, "FNO_name")
        col.prop(props, "ZU_area")
        col.prop(props, "h_relief")
        col.prop(props, "h_otn")
        col.prop(props, "h_abs")
        col.prop(props, "s_obsh")
        col.prop(props, "s_naz")
        col.prop(props, "s_podz")
        col.prop(props, "spp_gns")
        col.prop(props, "act_AGR")

        row = col.row()
        row.prop(props, "image", text="Image")
        row.operator("geojson.clear_image", text="", icon="X")

        col.prop(props, "other")
        col.prop(props, "coord_x")
        col.prop(props, "coord_y")

        col.label(text="Glasses")
        col.operator("geojson.add_glass", text="Добавить стекло")
        for i, glass in enumerate(props.glasses):
            box = col.box()
            box.prop(glass, "material_name")
            box.prop(glass, "R")
            box.prop(glass, "G")
            box.prop(glass, "B")
            box.prop(glass, "transparency")
            box.prop(glass, "refraction")
            box.prop(glass, "roughness")
            box.prop(glass, "metallicity")
            box.operator("geojson.remove_glass", text="Удалить стекло").index = i

        col.operator("geojson.export")

classes = [
    GlassItem,
    GeoJSONProperties,
    GEOJSON_OT_add_glass,
    GEOJSON_OT_remove_glass,
    GEOJSON_OT_clear_image,
    GEOJSON_OT_export,
    GEOJSON_PT_panel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.geojson_props = bpy.props.PointerProperty(type=GeoJSONProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.geojson_props

if __name__ == "__main__":
    register()
